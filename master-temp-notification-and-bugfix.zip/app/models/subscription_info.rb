class SubscriptionInfo
  attr_accessor :has_active_subscription, :expires, :trial_is_active_and_no_subscription_purchased
end