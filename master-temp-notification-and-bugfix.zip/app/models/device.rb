class Device < ActiveRecord::Base
  
  belongs_to :user

  

end
