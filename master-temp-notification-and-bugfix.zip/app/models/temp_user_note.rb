class TempUserNote < ActiveRecord::Base
end