class TagStatisticsReport
  attr_accessor :tag, :usage_count, :low_impact_max, :high_impact_max, :category, :low, :high
end