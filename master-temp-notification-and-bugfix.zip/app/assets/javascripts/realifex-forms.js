//Fade buttons on tap
$(document).ready(function() {
	$(".realifex-button").click(function() {
		$(this).hide();
	});
});