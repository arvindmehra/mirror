require 'test_helper'

class SecurityQuestionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
